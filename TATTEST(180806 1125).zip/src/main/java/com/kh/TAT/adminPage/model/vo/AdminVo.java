package com.kh.TAT.adminPage.model.vo;

public class AdminVo {

}
