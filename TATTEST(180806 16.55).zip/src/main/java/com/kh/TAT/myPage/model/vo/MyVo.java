package com.kh.TAT.myPage.model.vo;

public class MyVo {

}
