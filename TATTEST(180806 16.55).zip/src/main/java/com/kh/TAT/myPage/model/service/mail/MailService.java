package com.kh.TAT.myPage.model.service.mail;

public interface MailService {

	 public boolean send(String subject, String text, String from, String to);


}
