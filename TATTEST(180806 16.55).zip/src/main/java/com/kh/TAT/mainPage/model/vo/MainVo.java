package com.kh.TAT.mainPage.model.vo;

public class MainVo {

}
